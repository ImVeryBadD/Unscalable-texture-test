﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Effects;

namespace NETFramework
{
	public class radiusTextureEffect : ShaderEffect
	{
		public DependencyProperty InputProperty = ShaderEffect.RegisterPixelShaderSamplerProperty("Input", typeof(radiusTextureEffect), 0);
		public DependencyProperty TextureProperty = ShaderEffect.RegisterPixelShaderSamplerProperty("Texture", typeof(radiusTextureEffect), 1);
		public DependencyProperty TextureDimProperty = DependencyProperty.Register("TextureDim", typeof(Point), typeof(radiusTextureEffect), new UIPropertyMetadata(new Point(4D, 4D), PixelShaderConstantCallback(0)));
		public DependencyProperty ESizeProperty = DependencyProperty.Register("ESize", typeof(Point), typeof(radiusTextureEffect), new UIPropertyMetadata(new Point(50D, 100D), PixelShaderConstantCallback(1)));
		public DependencyProperty BorderColorProperty = DependencyProperty.Register("BorderColor", typeof(Color), typeof(radiusTextureEffect), new UIPropertyMetadata(Color.FromArgb(255, 0, 150, 255), PixelShaderConstantCallback(2)));
		public DependencyProperty BorderThicknessProperty = DependencyProperty.Register("BorderThickness", typeof(double), typeof(radiusTextureEffect), new UIPropertyMetadata(((double)(3D)), PixelShaderConstantCallback(3)));
		public radiusTextureEffect()
		{
			PixelShader pixelShader = new PixelShader();
			pixelShader.UriSource = new Uri("pack://application:,,,/radiusTexture.ps");
			this.PixelShader = pixelShader;

			this.UpdateShaderValue(InputProperty);
			this.UpdateShaderValue(TextureProperty);
			this.UpdateShaderValue(TextureDimProperty);
			this.UpdateShaderValue(ESizeProperty);
			this.UpdateShaderValue(BorderColorProperty);
			this.UpdateShaderValue(BorderThicknessProperty);
		}
		public Brush Input
		{
			get
			{
				return ((Brush)(this.GetValue(InputProperty)));
			}
			set
			{
				this.SetValue(InputProperty, value);
			}
		}
		public Brush Texture
		{
			get
			{
				return ((Brush)(this.GetValue(TextureProperty)));
			}
			set
			{
				this.SetValue(TextureProperty, value);
			}
		}
		public Point TextureDim
		{
			get
			{
				return ((Point)(this.GetValue(TextureDimProperty)));
			}
			set
			{
				this.SetValue(TextureDimProperty, value);
			}
		}
		public Point ESize
		{
			get
			{
				return ((Point)(this.GetValue(ESizeProperty)));
			}
			set
			{
				this.SetValue(ESizeProperty, value);
			}
		}
		public Point BorderColor
		{
			get
			{
				return ((Point)(this.GetValue(BorderColorProperty)));
			}
			set
			{
				this.SetValue(BorderColorProperty, value);
			}
		}
		public Point StrokeThickness
		{
			get
			{
				return ((Point)(this.GetValue(BorderThicknessProperty)));
			}
			set
			{
				this.SetValue(BorderThicknessProperty, value);
			}
		}
	}
}