﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace NETFramework
{
    public partial class MainWindow : Window
    {
        const int ii = 10, jj=10, freeSpace=20;
        public MainWindow()
        {
            InitializeComponent();

            for (int i = 0; i < ii; i++)
                for (int j = 0; j < jj; j++)
                {
                    Ellipse canvasEllipse = new Ellipse();
                    canvasEllipse.Fill = Brushes.Green;
                    canvasEllipse.StrokeThickness = 2;
                    canvasEllipse.Stroke = Brushes.Black;
                    canvasEllipse.Width = 80;
                    canvasEllipse.Height = 40;
                    canvasEllipse.Name = "posX" + i.ToString() + "X" + j.ToString();
                    borderTextureEffect ellipseEffect = new borderTextureEffect();
                    ellipseEffect.N = 3;
                    ellipseEffect.M = 5;
                    ellipseEffect.EllipsePos1 = new Point(freeSpace + j * canvasEllipse.Width, freeSpace + i * canvasEllipse.Height);
                    ellipseEffect.EllipsePos2 = new Point((canvasEllipse as Ellipse).Width + freeSpace + j * canvasEllipse.Width, (canvasEllipse as Ellipse).Height + freeSpace + i * canvasEllipse.Height);
                    canvasEllipse.Effect = ellipseEffect;
                    Canvas.Children.Add(canvasEllipse);
                    Canvas.SetLeft(canvasEllipse, freeSpace + canvasEllipse.Width * j);
                    Canvas.SetTop(canvasEllipse, freeSpace + canvasEllipse.Height * i);
                }
            //updateTitle();
        }

        private void TransitionSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            //Ellipse.Height = Canvas.Height = e.NewValue;
            //Ellipse.Width = Canvas.Width = e.NewValue * 2;
            updateTitle();
        }

        private void ToleranceSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            //EllipseChromaKey.Tolerance = e.NewValue;
            updateTitle();
        }

        private void LayoutRoot_MouseMove(object sender, MouseEventArgs e)
        {
            Point mousePos = e.GetPosition(this);
            //this.Title = string.Format("Mouse.GetPosition: "+ mousePos.X.ToString() + ", "+ mousePos.Y.ToString());
            var curLayoutRoot = System.Windows.LogicalTreeHelper.FindLogicalNode(this, "LayoutRoot");
            magnifyEffect canvasEffect = new magnifyEffect();
            canvasEffect.CenterPoint = new Point(mousePos.X / LayoutRoot.ActualWidth, mousePos.Y/LayoutRoot.ActualHeight);
            (curLayoutRoot as Grid).Effect = canvasEffect;
        }

        /*
private void LayoutRoot_MouseWheel(object sender, MouseWheelEventArgs e)
{
   if (e.Delta>0) //(Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
       EllipseScale.ScaleX = EllipseScale.ScaleY += 0.1;
   else
       EllipseScale.ScaleX = EllipseScale.ScaleY -= 0.1;
   ShaderEffect.ESize = new Point(Ellipse.Height / 2 * EllipseScale.ScaleY, Ellipse.Width / 2 * EllipseScale.ScaleX);
   updateTitle();


}
*/
        private void updateTitle()
        {/*
            this.Title = "Source: " + Ellipse.Width.ToString() + "x" + Ellipse.Height.ToString() +
                "  Tolerance: " + ShaderEffect.Tolerance +
                "  ESize: " + ShaderEffect.ESize.Y + "x" + ShaderEffect.ESize.X +
                "  Texture: " + (TextureImage.ImageSource as BitmapSource).PixelWidth + "x" + (TextureImage.ImageSource as BitmapSource).PixelHeight; //+
                "  Scaling: " + Math.Abs(EllipseScale.ScaleX) + "x";*/
        }

        private void ScrollViewer_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {
            for (int i = 0; i < ii; i++)
                for (int j = 0; j < jj; j++)
                {
                    var curEllipse = System.Windows.LogicalTreeHelper.FindLogicalNode(this, "posX" + i.ToString() + "X" + j.ToString());
                    ((curEllipse as Ellipse).Effect as borderTextureEffect).EllipsePos1 = new Point(freeSpace + j * (curEllipse as Ellipse).Width - e.HorizontalOffset, freeSpace + i * (curEllipse as Ellipse).Height - e.VerticalOffset);
                    ((curEllipse as Ellipse).Effect as borderTextureEffect).EllipsePos2 = new Point((curEllipse as Ellipse).Width + freeSpace + j * (curEllipse as Ellipse).Width - e.HorizontalOffset, (curEllipse as Ellipse).Height + freeSpace + i * (curEllipse as Ellipse).Height - e.VerticalOffset);
                }
            this.Title = "Window Size: "+e.ViewportHeight + "x" + e.ViewportWidth + "   " +
                "Current Offset: "+e.VerticalOffset + "x" + e.HorizontalOffset + "   " + 
                "Canvas Size: "+Canvas.ActualHeight + "x" + Canvas.ActualWidth + "   "+
                "LayoutRoot Size: "+LayoutRoot.ActualHeight + "x"+LayoutRoot.ActualWidth;
        }
    }
}
