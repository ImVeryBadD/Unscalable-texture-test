﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Shell;

namespace NETFramework
{
    public partial class MainWindow : Window
    {
        const int ii = 10, jj = 10, freeSpace = 20;
        public MainWindow()
        {
            InitializeComponent();
            for (int i = 0; i < ii; i++)
                for (int j = 0; j < jj; j++)
                {
                    Ellipse canvasEllipse = new Ellipse();
                    canvasEllipse.Fill = Brushes.Green;
                    canvasEllipse.StrokeThickness = 2;
                    canvasEllipse.Stroke = Brushes.Black;
                    canvasEllipse.Width = 80;
                    canvasEllipse.Height = 40;
                    canvasEllipse.Name = "posX" + i.ToString() + "X" + j.ToString();
                    borderTextureEffect ellipseEffect = new borderTextureEffect();
                    ellipseEffect.N = 3;
                    ellipseEffect.M = 5;
                    ellipseEffect.EllipsePos1 = new Point(freeSpace + j * canvasEllipse.Width, freeSpace + i * canvasEllipse.Height);
                    ellipseEffect.EllipsePos2 = new Point((canvasEllipse as Ellipse).Width + freeSpace + j * canvasEllipse.Width, (canvasEllipse as Ellipse).Height + freeSpace + i * canvasEllipse.Height);
                    canvasEllipse.Effect = ellipseEffect;
                    Canvas.Children.Add(canvasEllipse);
                    Canvas.SetLeft(canvasEllipse, freeSpace + canvasEllipse.Width * j);
                    Canvas.SetTop(canvasEllipse, freeSpace + canvasEllipse.Height * i);
                }
            //updateTitle();
        }

        private void TransitionSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            //Ellipse.Height = Canvas.Height = e.NewValue;
            //Ellipse.Width = Canvas.Width = e.NewValue * 2;
            updateTitle();
        }

        private void ToleranceSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            //EllipseChromaKey.Tolerance = e.NewValue;
            updateTitle();
        }

        private void Element_MouseMove(object sender, MouseEventArgs e)
        {
            Point mousePos = e.GetPosition(Canvas);
            magnifyEffect magnify = new magnifyEffect();
            magnify.InnerRadius = 0.008;
            magnify.OuterRadius = 0.012;
            magnify.AspectRatio = Canvas.Width / Canvas.Height;
            magnify.CenterPoint = new Point(mousePos.X / Canvas.Width, mousePos.Y / Canvas.Height);
            LayoutRoot.Effect = magnify;
            this.Title = "Window Size: " + Scroll.ViewportWidth + "x" + Scroll.ViewportHeight + "   " +
                "Current Offset: " + Scroll.VerticalOffset + "x" + Scroll.HorizontalOffset + "   " +
                "LayoutRoot Size: " + LayoutRoot.ActualHeight + "x" + LayoutRoot.ActualWidth + "   " +
                "Mouse pos: " + mousePos.X + "x" + mousePos.Y;
        }

        private void updateTitle()
        {

        }

        private void ScrollViewer_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {
            for (int i = 0; i < ii; i++)
                for (int j = 0; j < jj; j++)
                {
                    var curEllipse = System.Windows.LogicalTreeHelper.FindLogicalNode(this, "posX" + i.ToString() + "X" + j.ToString());
                    //((curEllipse as Ellipse).Effect as borderTextureEffect).EllipsePos1 = new Point(freeSpace + j * (curEllipse as Ellipse).Width - e.HorizontalOffset, freeSpace + i * (curEllipse as Ellipse).Height - e.VerticalOffset);
                    //((curEllipse as Ellipse).Effect as borderTextureEffect).EllipsePos2 = new Point((curEllipse as Ellipse).Width + freeSpace + j * (curEllipse as Ellipse).Width - e.HorizontalOffset, (curEllipse as Ellipse).Height + freeSpace + i * (curEllipse as Ellipse).Height - e.VerticalOffset);
                }
            this.Title = "Window Size: " + Scroll.ViewportWidth + "x" + Scroll.ViewportHeight + "   " +
                "Current Offset: " + Scroll.VerticalOffset + "x" + Scroll.HorizontalOffset + "   " +
                "LayoutRoot Size: " + LayoutRoot.ActualHeight + "x" + LayoutRoot.ActualWidth;
        }
    }
}
