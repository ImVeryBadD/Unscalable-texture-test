﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Shell;

namespace NETFramework
{
    public partial class MainWindow : Window
    {
        const int ii = 3, jj = 3, freeSpace = 100;
        public MainWindow()
        {
            InitializeComponent();
            chromaKeyTextureEffect chroma = new chromaKeyTextureEffect();
            BitmapImage img = new BitmapImage(new Uri("pack://application:,,,/texture.png"));
            chroma.Texture = new ImageBrush(img);
            chroma.TextureDim = new Point(img.Width, img.Height);
            DrawingVisual visual = new DrawingVisual();
            DrawingContext context = visual.RenderOpen();
            context.DrawRectangle(Brushes.Green, new Pen(Brushes.Red,3), new Rect(new Point(50, 50), new Point(100, 1000)));
            visual.Effect = chroma;
            context.Close();
            drawingSurface.AddVisual(visual);
            //drawingSurface.Effect = chroma;
        }

        private void TransitionSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            //Ellipse.Height = Canvas.Height = e.NewValue;
            //Ellipse.Width = Canvas.Width = e.NewValue * 2;
            updateTitle();
        }

        private void ToleranceSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            //EllipseChromaKey.Tolerance = e.NewValue;
            updateTitle();
        }

        /*
        private void Element_MouseMove(object sender, MouseEventArgs e)
        {
            Point mousePos = e.GetPosition(Canvas);
            magnifyEffect magnify = new magnifyEffect();
            magnify.InnerRadius = 0.008;
            magnify.OuterRadius = 0.012;
            magnify.AspectRatio = Canvas.Width / Canvas.Height;
            magnify.CenterPoint = new Point(mousePos.X / Canvas.Width, mousePos.Y / Canvas.Height);
            LayoutRoot.Effect = magnify;
            this.Title = "Window Size: " + Scroll.ViewportWidth + "x" + Scroll.ViewportHeight + "   " +
                "Current Offset: " + Scroll.VerticalOffset + "x" + Scroll.HorizontalOffset + "   " +
                "LayoutRoot Size: " + LayoutRoot.ActualHeight + "x" + LayoutRoot.ActualWidth + "   " +
                "Mouse pos: " + mousePos.X + "x" + mousePos.Y;
        }
        */

        private void updateTitle()
        {

        }

        private void ScrollViewer_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {
            for (int i = 0; i < ii; i++)
                for (int j = 0; j < jj; j++)
                {
                    var curEllipse = System.Windows.LogicalTreeHelper.FindLogicalNode(this, "posX" + i.ToString() + "X" + j.ToString());
                    //((curEllipse as Ellipse).Effect as borderTextureEffect).EllipsePos1 = new Point(freeSpace + j * (curEllipse as Ellipse).Width - e.HorizontalOffset, freeSpace + i * (curEllipse as Ellipse).Height - e.VerticalOffset);
                    //((curEllipse as Ellipse).Effect as borderTextureEffect).EllipsePos2 = new Point((curEllipse as Ellipse).Width + freeSpace + j * (curEllipse as Ellipse).Width - e.HorizontalOffset, (curEllipse as Ellipse).Height + freeSpace + i * (curEllipse as Ellipse).Height - e.VerticalOffset);
                }
            this.Title = "Window Size: " + Scroll.ViewportWidth + "x" + Scroll.ViewportHeight + "   " +
                "Current Offset: " + Scroll.VerticalOffset + "x" + Scroll.HorizontalOffset + "   " +
                "drawingSurface RenderSize: " + drawingSurface.RenderSize.Width + "x" + drawingSurface.RenderSize.Height;
        }
    }
    public class DrawingField : FrameworkElement
    {
        private List<Visual> visuals = new List<Visual>();
        protected override int VisualChildrenCount
        {
            get { return visuals.Count; }
        }
        protected override Visual GetVisualChild(int index)
        {
            return visuals[index];
        }
        public void AddVisual(Visual visual)
        {
            visuals.Add(visual);
            this.AddVisualChild(visual);
            //base.AddLogicalChild(visual);
        }
    }
}
