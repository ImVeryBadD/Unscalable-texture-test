﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Media.Media3D;


namespace NETFramework
{

	public class borderTextureEffect : ShaderEffect
	{
		public static readonly DependencyProperty InputProperty = ShaderEffect.RegisterPixelShaderSamplerProperty("Input", typeof(borderTextureEffect), 0);
		public static readonly DependencyProperty BorderColorProperty = DependencyProperty.Register("BorderColor", typeof(Color), typeof(borderTextureEffect), new UIPropertyMetadata(Color.FromArgb(255, 255, 0, 0), PixelShaderConstantCallback(0)));
		public static readonly DependencyProperty NProperty = DependencyProperty.Register("N", typeof(double), typeof(borderTextureEffect), new UIPropertyMetadata(((double)(4D)), PixelShaderConstantCallback(1)));
		public static readonly DependencyProperty MProperty = DependencyProperty.Register("M", typeof(double), typeof(borderTextureEffect), new UIPropertyMetadata(((double)(4D)), PixelShaderConstantCallback(2)));
		public static readonly DependencyProperty EllipsePos1Property = DependencyProperty.Register("EllipsePos1", typeof(Point), typeof(borderTextureEffect), new UIPropertyMetadata(new Point(20D, 20D), PixelShaderConstantCallback(3)));
		public static readonly DependencyProperty EllipsePos2Property = DependencyProperty.Register("EllipsePos2", typeof(Point), typeof(borderTextureEffect), new UIPropertyMetadata(new Point(100D, 60D), PixelShaderConstantCallback(4)));
		public borderTextureEffect()
		{
			this.PaddingTop = this.PaddingRight = this.PaddingBottom = this.PaddingLeft = N + M;
			PixelShader pixelShader = new PixelShader();
			pixelShader.UriSource = new Uri("pack://application:,,,/borderTexture.ps");
			this.PixelShader = pixelShader;

			this.UpdateShaderValue(InputProperty);
			this.UpdateShaderValue(BorderColorProperty);
			this.UpdateShaderValue(NProperty);
			this.UpdateShaderValue(MProperty);
			this.UpdateShaderValue(EllipsePos1Property);
			this.UpdateShaderValue(EllipsePos2Property);
		}
		public Brush Input
		{
			get
			{
				return ((Brush)(this.GetValue(InputProperty)));
			}
			set
			{
				this.SetValue(InputProperty, value);
			}
		}
		public Color BorderColor
		{
			get
			{
				return ((Color)(this.GetValue(BorderColorProperty)));
			}
			set
			{
				this.SetValue(BorderColorProperty, value);
			}
		}
		public double N
		{
			get
			{
				return ((double)(this.GetValue(NProperty)));
			}
			set
			{
				this.SetValue(NProperty, value);
			}
		}
		public double M
		{
			get
			{
				return ((double)(this.GetValue(MProperty)));
			}
			set
			{
				this.SetValue(MProperty, value);
			}
		}
		public Point EllipsePos1
		{
			get
			{
				return ((Point)(this.GetValue(EllipsePos1Property)));
			}
			set
			{
				this.SetValue(EllipsePos1Property, value);
			}
		}
		public Point EllipsePos2
		{
			get
			{
				return ((Point)(this.GetValue(EllipsePos2Property)));
			}
			set
			{
				this.SetValue(EllipsePos2Property, value);
			}
		}
	}
}